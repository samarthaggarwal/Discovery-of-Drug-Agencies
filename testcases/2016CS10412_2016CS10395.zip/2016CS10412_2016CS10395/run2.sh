./solution $1.satoutput $1.subgraphs
