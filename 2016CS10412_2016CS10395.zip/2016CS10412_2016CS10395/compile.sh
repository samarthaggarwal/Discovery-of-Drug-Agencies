g++ -o main main.cpp graph.cpp -std=c++11
g++ -o solution solution.cpp -std=c++11
