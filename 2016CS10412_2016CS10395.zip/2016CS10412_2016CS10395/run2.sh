./solution test.satoutput $1.subgraphs
